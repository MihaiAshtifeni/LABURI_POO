package com.company.lab;

public class Main {

    public static void main(String[] args) {

    }
}
