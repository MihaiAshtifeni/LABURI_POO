package com.company.lab;

import java.util.Date;

public class Staff extends Department{
    protected Date joined;
    protected String[] education;
    protected String[] certification;
    protected String[] languages;
}
