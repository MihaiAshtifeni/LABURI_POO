package com.company.lab;

public class Hospital {
    protected String name;
    protected String address;
    protected String phone;

}
