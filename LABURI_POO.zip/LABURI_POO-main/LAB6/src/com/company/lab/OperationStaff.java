package com.company.lab;

public class OperationStaff extends Staff{

}
