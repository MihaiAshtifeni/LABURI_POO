package com.company.lab;

public class Doctor  extends OperationStaff{
    protected String[] speciality;
    protected String[] locations;
}
