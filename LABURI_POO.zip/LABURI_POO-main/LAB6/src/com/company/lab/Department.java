package com.company.lab;

public class Department extends Hospital {

}
