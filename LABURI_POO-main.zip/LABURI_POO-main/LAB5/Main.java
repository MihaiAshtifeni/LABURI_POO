//LAB 5 Morari Gheorghe FAF - 192
public class Main
{
	public static void main(String[] args) {
	    //Print all states from J
	    J j = new J("HEHEHE");
		j.print();
	}
}
